<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- Breadcrumb-->
<div class="breadcrumb-holder">
    <div class="container-fluid">
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo adminRoute(); ?>">Home</a></li>
            <li class="breadcrumb-item active">FaucetPay.io Addon</li>
        </ul>
    </div>
</div>
<!-- /. ROW  -->
<section>
    <div class="container-fluid">
        <header>
            <?php $this->load->view('admin/includes/alerts'); ?>
            <h1 class="h3 display">FaucetPay.io Addon</h1>
        </header>

        <div class="row">
            <div class="col-sm-12 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        Settings
						<small class="text-muted pull-right clearfix">v<?php echo $this->addon_version; ?></small>
                    </div>
                    <div class="card-body">
                        <h4>API Settings</h4>
                        <form method="post" action="<?php echo adminRoute('faucetpay'); ?>"
                              class="form-horizontal" style="margin-top: 1em">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>API Key</label>
                                        <input type="text" class="form-control"
                                               name="api" value="<?php echo $config['api']; ?>" required>
                                        <small>Api Key</small>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <button type="submit" class="btn btn-info"><i class="fa fa-save"></i>
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <h4>Actions</h4>
                        <dl class="row">
                            <dt class="col-lg-3"><a href="<?php echo adminRoute('faucetpay/balance');?>" class="btn btn-success btn-sm"><i class="fa fa-bank"></i> Balance</a></dt>
                            <dd class="col-lg-9"> Check your account balance</dd>
                            <dt class="col-lg-3"><a href="<?php echo adminRoute('faucetpay/payouts');?>" class="btn btn-success btn-sm"><i class="fa fa-bar-chart"></i> Payouts</a></dt>
                            <dd class="col-lg-9"> Check latest 100 payouts</dd>
                        </dl>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo adminRoute('faucetpay/uninstall'); ?>" class="btn btn-danger"><i
                                    class="fa fa-cog"></i> Uninstall</a>
                    </div>
                </div>
            </div>

			<div class="col-sm-12 col-lg-12">
				<div class="card">
					<div class="card-header">
						Error Logs
						<a href="<?php echo adminRoute('faucetpay/empty_logs');?>" class="btn btn-danger btn-sm pull-right clearfix"><i class="fa fa-trash"></i> Delete All</a>
					</div>
					<div class="card-body">
						<div class="table-responsive">
							<table class="table table-striped">
								<thead>
								<tr>
									<th>#</th>
									<th>User</th>
									<th>Message</th>
									<th>Date</th>
								</tr>
								</thead>
								<tbody>
								<?php
								if($error_logs):
									foreach ($error_logs as $item) {
										echo '<tr>';
										echo '<td>'.$item['id'].'</td>';
										echo '<td><a href="'.adminRoute('users/view/'.$item['user_id']).'">'.$item['user_id'].'</a></td>';
										echo '<td>'.$item['message'].'</td>';
										echo '<td>'.$item['created_at'].'</td>';
										echo '</tr>';
									}
								else:
									echo '<tr><td colspan="4" class="text-center">No results found!</td>';
								endif;
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>

			<div class="col-sm-12 col-lg-12">
				<div class="card">
					<div class="card-header">
						Last 100 Payouts
					</div>
					<div class="card-body">
						<div class="table-responsive">
							<table class="table table-striped">
								<thead>
								<tr>
									<th>Address</th>
									<th>Amount</th>
									<th>Date</th>
								</tr>
								</thead>
								<tbody>
								<?php
								if($this->session->flashdata('payouts_list')):
									foreach (json_decode($this->session->flashdata('payouts_list'),1) as $item) {
										echo '<tr>';
										echo '<td>'.$item['to'].'</td>';
										echo '<td>'.currencyFormat($item['amount']/100000000).' '.settings('currency_code').'</td>';
										echo '<td>'.$item['date'].'</td>';
										echo '</tr>';
									}
								else:
									echo '<tr><td colspan="3" class="text-center">No results found!</td>';
								endif;
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
        </div>
    </div>
</section>
