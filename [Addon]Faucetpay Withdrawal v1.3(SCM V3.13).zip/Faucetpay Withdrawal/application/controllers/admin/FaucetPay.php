<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FaucetPay extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->is_admin_loggedin();
		$this->load->model('faucetpay_model');
        $this->check_status = $this->faucetpay_model->checkStatus();
		$this->addon_version = '1.3';
		if($this->check_status){
            $this->settings = $this->faucetpay_model->getSettings();
			$this->errorLogs = $this->faucetpay_model->getErrorLogs();
        }
	}

	public function index()
	{
		if(!$this->check_status){
			return $this->admin_view('addons/faucetpay/install');
		}
        $this->form_validation->set_rules('api', 'API Key', 'trim|required');

        if ($this->form_validation->run() === TRUE) {
            if($this->faucetpay_model->update()){
                $this->session->set_flashdata('success_msg','Settings updated with success!');
            }
            redirect(current_url());
        }
		return $this->admin_view('addons/faucetpay/index',['config' => $this->settings, 'error_logs' => $this->errorLogs]);
	}

	public function emptyLogs()
	{
		if(!$this->check_status){
			return $this->admin_view('addons/faucetpay/install');
		}
		$this->faucetpay_model->emptyLogs();
		$this->session->set_flashdata('success_msg','Error logs deleted successfully!');
		redirect(adminRoute('faucetpay'));
	}

	public function checkBalance()
    {
        if(!$this->check_status){
            return $this->admin_view('addons/faucetpay/install');
        }
		// API request
		$json_result = $this->requestCall('balance');
        if($json_result->status=='200'){
            $this->session->set_flashdata('success_msg','Your current balance: '.$json_result->balance. ' satoshis of '.$json_result->currency);
        }else{
            $this->session->set_flashdata('error_msg', 'Error '.$json_result->status.'. '.$json_result->message);
        }
        redirect(adminRoute('faucetpay'));
    }

	public function payouts()
    {
        if(!$this->check_status){
            return $this->admin_view('addons/faucetpay/install');
        }
		// API request
		$json_result = $this->requestCall('payouts',['count' => 100]);
        if($json_result->status=='200'){
            $this->session->set_flashdata('payouts_list',$json_result->rewards);
        }else{
            $this->session->set_flashdata('error_msg', 'Error '.$json_result->status.'. '.$json_result->message);
        }
        redirect(adminRoute('faucetpay'));
    }

	public function install()
	{
		$this->faucetpay_model->install();
		//Update routes
        $getRoutes = file_get_contents(APPPATH.'config/routes.php');
        $newRoutes = str_replace('$route[\'withdrawal\'][\'post\']', '//$route[\'withdrawal\'][\'post\']', $getRoutes);
        file_put_contents(APPPATH . 'config/routes.php', $newRoutes);
		$this->session->set_flashdata('success_msg','Addon installed with success!');
		redirect(adminRoute('faucetpay'));
	}

	public function uninstall()
	{
		$this->faucetpay_model->uninstall();
        //Update routes
        $getRoutes = file_get_contents(APPPATH.'config/routes.php');
        $newRoutes = str_replace('//$route[\'withdrawal\'][\'post\']', '$route[\'withdrawal\'][\'post\']', $getRoutes);
        file_put_contents(APPPATH . 'config/routes.php', $newRoutes);
		$this->session->set_flashdata('success_msg','Addon uninstalled with success!');
		redirect(adminRoute('faucetpay'));
	}

	private function requestCall($method = 'balance', $optinal_fields = array(''))
	{
		// Initiate cURL and set headers/options
		$ch  = curl_init();
		$fields = array_merge(['api_key' => $this->settings['api'], 'currency' => settings('currency_code')], $optinal_fields);
		// this was a POST method
		curl_setopt($ch, CURLOPT_URL, 'https://faucetpay.io/api/v1/'.$method);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		// Execute the cURL request
		$result = curl_exec($ch);
		curl_close($ch);
		return json_decode($result);
	}
}
