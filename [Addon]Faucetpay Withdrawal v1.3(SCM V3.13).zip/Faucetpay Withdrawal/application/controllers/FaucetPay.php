<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FaucetPay extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('faucetpay_model');
        $this->load->model('users_model');
        $this->check_status = $this->faucetpay_model->checkStatus();
        if($this->check_status){
            $this->settings = $this->faucetpay_model->getSettings();
        }

        if(!$this->ion_auth->logged_in()){
            redirect(base_url());
        }
        $this->userdata = $this->ion_auth->user()->row();
    }

    public function withdrawal()
    {
        $this->form_validation->set_rules('amount', 'Amount', 'trim|required|numeric|greater_than_equal_to['.settings('min_withdraw').']|less_than_equal_to['.settings('max_withdraw').']');

        if ($this->form_validation->run() === TRUE)
        {
            if($this->input->post('amount',true) > $this->userdata->balance){
                $this->session->set_flashdata('error_msg','You don\'t have enough earning blance to withdrawal the given amount!');
                redirect(current_url());
            }
            //Start Instant Withdrawal
            $amount = $this->input->post('amount',true);
            //Convert to satoshi
			$amount_satoshi = $amount * 100000000;

			//Create withdrawal. Return ID (int)
			$new_withdrawal = $this->faucetpay_model->create_withdrawal();

			// Initiate cURL and set headers/options
			$ch  = curl_init();
			// this was a POST method
			curl_setopt($ch, CURLOPT_URL, 'https://faucetpay.io/api/v1/send');
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, [
				'api_key' => $this->settings['api'],
				'amount' => $amount_satoshi,
				'to' => $this->userdata->username,
				'currency' => settings('currency_code')
			]);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			// Execute the cURL request
			$result = curl_exec($ch);
			curl_close($ch);
			$withdrawal = json_decode($result);

            if($withdrawal->status!='200'){
                if($withdrawal->status=='456'){
					$this->session->set_flashdata('error_msg', 'You need to create an account at <a href="//faucetpay.io" target="_blank">FaucetPay.io</a> in order to receive your payment.');
				}else{
					$this->session->set_flashdata('error_msg', 'An unexpected error has occurred and your payment cannot be made. Try again or contact the administrator.');
					//Log error message
					$error_message = 'FaucetPay.io. Withdrawal error message: '.$withdrawal->message.'. Request: '.$this->input->post('amount',true).'. Amount: '.$amount. ' Satoshi: '.$amount_satoshi;
					$this->faucetpay_model->createErrorLog($error_message, $this->userdata->id);
					log_message('error', $error_message);
				}
				//Update withdrawal request
				$this->faucetpay_model->update_withdrawal($new_withdrawal, 'CANCELED');
                redirect(current_url());
            }

            if($this->faucetpay_model->update_withdrawal($new_withdrawal, 'SUCCESS', $withdrawal->payout_user_hash)){
                $this->session->set_flashdata('success_msg','Withdrawal paid successfully!');
                redirect(current_url());
            }
        }
        $this->site_view('withdrawal');
    }
}
