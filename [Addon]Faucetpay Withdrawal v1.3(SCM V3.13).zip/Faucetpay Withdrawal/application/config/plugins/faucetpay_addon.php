<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Admin Routes
 */
$route[$adminPrefix.'/faucetpay'] = 'admin/FaucetPay/index';
$route[$adminPrefix.'/faucetpay/balance'] = 'admin/FaucetPay/checkBalance';
$route[$adminPrefix.'/faucetpay/payouts'] = 'admin/FaucetPay/payouts';
$route[$adminPrefix.'/faucetpay/install'] = 'admin/FaucetPay/install';
$route[$adminPrefix.'/faucetpay/uninstall'] = 'admin/FaucetPay/uninstall';
$route[$adminPrefix.'/faucetpay/empty_logs'] = 'admin/FaucetPay/emptyLogs';

/*
 * Site Routes
 */
if(!$route['withdrawal']['post']) {
	$route['withdrawal']['post'] = 'FaucetPay/withdrawal';
}
