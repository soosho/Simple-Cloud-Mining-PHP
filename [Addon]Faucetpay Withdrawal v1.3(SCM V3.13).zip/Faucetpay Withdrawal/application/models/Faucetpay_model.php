<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Faucetpay_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table_name = 'addon_faucetpay';
	}

	function checkStatus()
	{
		return $this->db->table_exists($this->table_name);
	}

	function getSettings()
	{
		return $this->db->where('id',1)->get($this->table_name)->row_array();
	}

	function update()
    {
        return $this->db->where('id',1)->update($this->table_name, [
            'api' => $this->input->post('api',true),
        ]);
    }

	/**
	 * @return int ID
	 */
	function create_withdrawal()
	{
		$user = $this->ion_auth->user()->row();
		$amount = $this->input->post('amount', true);
		//Create withdrawal request
		$this->db->insert('user_withdrawal', [
			'user_id' => $user->id,
			'amount' => $amount,
			'status' => 'PENDING',
		]);
		//Get id
		$withdrawal = $this->db->insert_id();
		//Debit user balance
		$this->updateUserBalance($user->id, $amount);
		return $withdrawal;
	}

	/**
	 * @param int $id
	 * @param string $status
	 * @param null $tx_id
	 * @return mixed
	 */
	function update_withdrawal($id, $status = 'CANCELED', $tx_id = null)
	{
		$user = $this->ion_auth->user()->row();
		$amount = $this->input->post('amount', true);

		if($status == 'SUCCESS'){
			$data = [
				'status' => 'SUCCESS',
				'tx' => $tx_id,
				'date_paid' => date('Y-m-d H:i:s'),
			];
		}else{
			$data = [
				'status' => 'CANCELED',
			];
			//Credit user balance
			$this->updateUserBalance($user->id, $amount, 'increment');
		}
		return $this->db
			->where('id', $id)
			->update('user_withdrawal', $data);
	}

	/**
	 * @param $user_id int|string
	 * @param $amount string
	 * @param $type string increment|decrement
	 * @return mixed
	 */
	function updateUserBalance($user_id, $amount, $type = 'decrement')
	{
		if($type === 'increment'){
			//Credit user balance
			return $this->db->where('id', $user_id)->set('balance', 'balance+' . $amount, FALSE)->update('users');
		}
		//Debit user balance
		return $this->db->where('id', $user_id)->set('balance', 'balance-' . $amount, FALSE)->update('users');
	}

	function getErrorLogs()
	{
		return $this->db->order_by('id','DESC')->get($this->table_name.'_logs')->result_array();
	}

	function emptyLogs()
	{
		return $this->db->empty_table($this->table_name.'_logs');
	}

	function createErrorLog($message, $user)
	{
		$this->db->insert($this->table_name.'_logs',[
			'message' => $message,
			'user_id' => $user,
		]);
	}

    public function install()
    {
		//Register addon
		$this->db->insert('addons',[
			'name' => 'faucetpay'
		]);
		//Register addon menu
		$this->db->insert('addons_menu',[
			'slug' => 'faucetpay',
			'route' => 'faucetpay',
			'name' => 'FaucetPay',
			'icon' => 'fa-cube'
		]);
		//Create tables
		$this->db->query("CREATE TABLE `addon_faucetpay` ( `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT , `api` VARCHAR(191) NOT NULL, PRIMARY KEY (`id`)) ENGINE = InnoDB;");
		$this->db->query("CREATE TABLE `addon_faucetpay_logs` ( `id` INT(11) NOT NULL AUTO_INCREMENT , `user_id` INT(11) NOT NULL , `message` TEXT NOT NULL , `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP , PRIMARY KEY (`id`)) ENGINE = InnoDB;");

		//Insert default config
        $this->db->insert('addon_faucetpay',['api' => 'API_KEY_HERE']);
    }

	public function uninstall()
	{
		//Register addon
		$this->db->delete('addons',[
			'name' => 'faucetpay'
		]);
		//Register addon menu
		$this->db->delete('addons_menu',[
			'slug' => 'faucetpay'
		]);
		//Create tables
		$this->db->query("DROP TABLE `addon_faucetpay`");
		$this->db->query("DROP TABLE `addon_faucetpay_logs`");
	}
}
